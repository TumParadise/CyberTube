package com.cybertube.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybertube.app.BuildConfig
import com.cybertube.app.core.Store

private data class QOpt(val height: Int, val label: String)

private val qualityOptions = listOf(
    QOpt(0, "AUTO  (best up to 720p)"),
    QOpt(144, "144p"),
    QOpt(240, "240p"),
    QOpt(360, "360p"),
    QOpt(480, "480p"),
    QOpt(720, "720p"),
    QOpt(1080, "1080p"),
    QOpt(1440, "1440p"),
    QOpt(2160, "BEST  (highest available)"),
    QOpt(-1, "AUDIO ONLY"),
)

private data class OssLib(val name: String, val license: String, val url: String, val note: String)

private val ossLibs = listOf(
    OssLib("NewPipeExtractor", "GPL-3.0", "https://github.com/TeamNewPipe/NewPipeExtractor", "YouTube data extraction"),
    OssLib("NewPipe (code adapted)", "GPL-3.0", "https://github.com/TeamNewPipe/NewPipe", "PoToken provider, YouTube HTTP data source"),
    OssLib("AndroidX Media3 / ExoPlayer", "Apache-2.0", "https://github.com/androidx/media", "Playback engine, media session"),
    OssLib("Jetpack Compose & Material 3", "Apache-2.0", "https://developer.android.com/jetpack/compose", "UI toolkit"),
    OssLib("Coil", "Apache-2.0", "https://github.com/coil-kt/coil", "Image loading"),
    OssLib("OkHttp", "Apache-2.0", "https://github.com/square/okhttp", "HTTP client"),
    OssLib("RxJava / RxAndroid", "Apache-2.0", "https://github.com/ReactiveX/RxJava", "Used by the extractor layer"),
    OssLib("Kotlin Coroutines", "Apache-2.0", "https://github.com/Kotlin/kotlinx.coroutines", "Async"),
    OssLib("nanojson", "Apache-2.0", "https://github.com/mmastrac/nanojson", "JSON parsing (extractor dependency)"),
)

@Composable
fun SettingsScreen() {
    val cur = Store.defaultHeight.intValue
    val uri = LocalUriHandler.current

    LazyColumn(Modifier.fillMaxSize()) {
        item { SectionLabel("// SETTINGS") }

        item {
            Column(Modifier.padding(horizontal = 12.dp)) {
                Text("DEFAULT VIDEO QUALITY", color = Cy.text, style = MaterialTheme.typography.titleSmall)
                Text(
                    "Every video starts at this quality. If a video doesn't offer it, the closest lower one is used.",
                    color = Cy.dim, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp),
                )
            }
        }
        items(qualityOptions, key = { it.height }) { o ->
            Row(
                Modifier.fillMaxWidth().clickable { Store.setDefaultHeight(o.height) }.padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(
                    selected = cur == o.height,
                    onClick = { Store.setDefaultHeight(o.height) },
                    colors = RadioButtonDefaults.colors(selectedColor = Cy.green, unselectedColor = Cy.dim),
                )
                Text(o.label, color = if (cur == o.height) Cy.green else Cy.text, fontSize = 13.sp)
            }
        }

        item { Spacer(Modifier.height(12.dp)); SectionLabel("// ABOUT") }
        item {
            Column(Modifier.padding(horizontal = 12.dp)) {
                Text("CyberTube", color = Cy.green, style = MaterialTheme.typography.titleMedium)
                Text("version ${BuildConfig.VERSION_NAME}", color = Cy.dim, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row {
                    Text("Created by ", color = Cy.dim, fontSize = 13.sp)
                    Text("Tum", color = Cy.cyan, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "An unofficial YouTube client. Not affiliated with or endorsed by YouTube or Google. " +
                        "Subscriptions and history are stored on this device only.",
                    color = Cy.dim, fontSize = 11.sp,
                )
            }
        }

        item { Spacer(Modifier.height(12.dp)); SectionLabel("// OPEN SOURCE") }
        item {
            Text(
                "CyberTube includes code adapted from NewPipe and uses NewPipeExtractor, both GPL-3.0, " +
                    "so this app is distributed under GPL-3.0 as well. Libraries used:",
                color = Cy.dim, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
        items(ossLibs, key = { it.name }) { lib ->
            Column(
                Modifier.fillMaxWidth().clickable { runCatching { uri.openUri(lib.url) } }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(lib.name, color = Cy.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Text(lib.license, color = Cy.cyan, fontSize = 11.sp)
                }
                Text(lib.note, color = Cy.dim, fontSize = 11.sp)
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
